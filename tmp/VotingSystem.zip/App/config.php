<?php
/*
 * @category Lib
 * @package Test Suit
 * @copyright 2011, 2012 Dmitry Sheiko (http://dsheiko.com)
 * @license GNU
 */

return array(
    "adapter" => "mysqli",
    "host" => "172.20.44.254",
    "username" => "VotingSysUser",
    "password" => "VoterPass",
    "dbname" => "VotingSystem",
);